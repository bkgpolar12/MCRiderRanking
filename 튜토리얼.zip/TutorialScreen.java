package com.example.rankinglog;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Objects;

public class TutorialScreen extends Screen {
    private final Screen parent;
    private int page = 0;

    // 튜토리얼 페이지 정보 (이미지 경로, 제목, 설명)
    private record TutorialPage(Identifier image, String title, String desc) {}

    private final List<TutorialPage> pages = List.of(
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_2.png"), "1. 랭킹 메뉴 단축키", "마인크래프트 조작 설정에서 MCRiderRanking 단축키를 지정하세요.\n해당 키를 누르면 언제든지 모드 메인 화면이 열립니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_3.png"), "2. 신나게 달리기 (자동 기록)", "별도의 버튼을 누를 필요가 없습니다!\n트랙을 달리고 완주하면 모드가 알아서 기록을 측정해 서버에 전송합니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_4.png"), "3. 내 순위와 랭킹 확인하기", "메인 화면의 랭킹 버튼을 눌러 트랙별 순위를 확인하세요.\n모드, 카트바디, 엔진 필터를 사용해 특정 기록만 모아볼 수도 있습니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_5.png"), "4. 프로필 꾸미고 칭호 달기", "내 프로필에서 칭호를 장착하고 자기소개를 작성해 보세요.\n달성한 업적(칭호)은 랭킹 게시판에서 내 닉네임 옆에 멋지게 표시됩니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_1.png"), "5. 특별 이벤트 참여하기", "메인 화면의 이벤트 버튼을 통해 진행 중인 한정 이벤트에 참여하세요!\n참여 버튼을 누르고 특정 트랙을 달리면 이벤트 랭킹에 등록됩니다.")
    );

    private ButtonWidget prevBtn;
    private ButtonWidget nextBtn;

    // 레이아웃 유지를 위한 전역 변수
    private int boxX, boxY, boxW, boxH;

    public TutorialScreen(Screen parent) {
        super(Text.literal("모드 튜토리얼"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // 1. 16:9 비율 유지를 위한 화면 가용 공간 계산
        int paddingX = 80;  // 좌우 여백을 더 늘려서 기본 크기를 줄임
        int paddingY = 130; // 상하 여백

        int maxW = this.width - paddingX;
        int maxH = this.height - paddingY;

        // 2. 너비를 기준으로 16:9 높이 임시 계산
        this.boxW = maxW;
        this.boxH = (int) (this.boxW / (16.0f / 9.0f));

        // 3. 높이가 화면 밖으로 나간다면 너비를 축소
        if (this.boxH > maxH) {
            this.boxH = maxH;
            this.boxW = (int) (this.boxH * (16.0f / 9.0f));
        }

        // ★ 4. 최대 크기 하향 조정 (기존 640 -> 400으로 줄여서 부담스럽지 않게 만듦)
        int absoluteMaxWidth = 400;
        if (this.boxW > absoluteMaxWidth) {
            this.boxW = absoluteMaxWidth;
            this.boxH = (int) (this.boxW / (16.0f / 9.0f));
        }

        // 5. 최종 좌표 확정
        this.boxX = cx - (this.boxW / 2);

        // 화면이 너무 작아졌을 때 타이틀이 잘리지 않도록 동적 Y 위치 계산
        this.boxY = Math.max(35, (this.height - this.boxH - 80) / 2);

        // 6. 버튼 위치 (사진 박스 하단 + 텍스트 여백 아래에 고정)
        int buttonY = this.boxY + this.boxH + 65;

        prevBtn = addDrawableChild(ButtonWidget.builder(Text.literal("◀ 이전"), b -> {
            if (page > 0) { page--; updateButtons(); }
        }).dimensions(cx - 110, buttonY, 100, 20).build());

        nextBtn = addDrawableChild(ButtonWidget.builder(Text.literal("다음 ▶"), b -> {
            if (page < pages.size() - 1) {
                page++;
                updateButtons();
            } else {
                // 테스트가 끝나면 아래 두 줄의 주석을 해제하여 튜토리얼 다시보기를 방지하세요.
                // ModConfig.get().hasSeenTutorial = true;
                // ModConfig.save();
                if (parent == null) {
                    this.close();
                } else {
                    Objects.requireNonNull(this.client).setScreen(parent);
                }
            }
        }).dimensions(cx + 10, buttonY, 100, 20).build());

        updateButtons();
    }

    private void updateButtons() {
        prevBtn.active = (page > 0);
        if (page == pages.size() - 1) {
            nextBtn.setMessage(Text.literal("시작하기 ✔"));
        } else {
            nextBtn.setMessage(Text.literal("다음 ▶"));
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, ModConfig.get().getBgColor());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        int cx = this.width / 2;

        // 1. 상단 타이틀
        context.getMatrices().push();
        float titleScale = this.width < 400 ? 1.2f : 1.5f;
        context.getMatrices().scale(titleScale, titleScale, 1.0f);
        context.drawCenteredTextWithShadow(textRenderer, "§6[ 튜토리얼 ]", (int)(cx / titleScale), (int)((this.boxY - 18) / titleScale), 0xFFFFFF);
        context.getMatrices().pop();

        // 2. 이미지 박스 테두리 및 배경
        context.fill(this.boxX - 1, this.boxY - 1, this.boxX + this.boxW + 1, this.boxY + this.boxH + 1, 0xFF555555);
        context.fill(this.boxX, this.boxY, this.boxX + this.boxW, this.boxY + this.boxH, 0xFF000000);

        TutorialPage current = pages.get(page);

        // 3. 이미지 렌더링 (16:9 비율 유지)
        context.drawTexture(
                net.minecraft.client.render.RenderLayer::getGuiTextured,
                current.image(),
                this.boxX, this.boxY,
                0.0F, 0.0F,
                this.boxW, this.boxH,
                this.boxW, this.boxH
        );

        // 4. 하단 텍스트 영역
        int textY = this.boxY + this.boxH + 12;
        context.drawCenteredTextWithShadow(textRenderer, "§e§l" + current.title(), cx, textY, 0xFFFFFF);

        int descY = textY + 14;
        // 텍스트가 잘리지 않도록 텍스트 박스 너비 여유 확보
        int maxTextWidth = Math.max(300, this.boxW + 40);
        List<OrderedText> wrapped = textRenderer.wrapLines(Text.literal(current.desc()), maxTextWidth);
        for (OrderedText line : wrapped) {
            context.drawCenteredTextWithShadow(textRenderer, line, cx, descY, 0xDDDDDD);
            descY += 12;
        }

        // 5. 페이지 번호
        context.drawCenteredTextWithShadow(textRenderer, (page + 1) + " / " + pages.size(), cx, nextBtn.getY() - 15, 0xAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}