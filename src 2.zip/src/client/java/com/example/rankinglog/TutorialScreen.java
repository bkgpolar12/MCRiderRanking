package com.example.rankinglog;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Objects;

public class TutorialScreen extends Screen {
    private final Screen parent;
    private int page = 0;

    // 튜토리얼 페이지 정보 (이미지 경로, 제목, 설명)
    private record TutorialPage(Identifier image, String title, String desc) {}

    // ★ new Identifier 대신 Identifier.of 를 사용합니다!
    private final List<TutorialPage> pages = List.of(
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_2.png"), "1. 랭킹 메뉴 단축키", "마인크래프트 조작 설정에서 MCRiderRanking 단축키를 지정하세요.\n해당 키를 누르면 언제든지 모드 메인 화면이 열립니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_3.png"), "2. 신나게 달리기 (자동 기록)", "별도의 버튼을 누를 필요가 없습니다!\n트랙을 달리고 완주하면 모드가 알아서 기록을 측정해 서버에 전송합니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_4.png"), "3. 내 순위와 랭킹 확인하기", "메인 화면의 랭킹 버튼을 눌러 트랙별 순위를 확인하세요.\n모드, 카트바디, 엔진 필터를 사용해 특정 기록만 모아볼 수도 있습니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_5.png"), "4. 프로필 꾸미고 칭호 달기", "내 프로필에서 칭호를 장착하고 자기소개를 작성해 보세요.\n달성한 업적(칭호)은 랭킹 게시판에서 내 닉네임 옆에 멋지게 표시됩니다."),
            new TutorialPage(Identifier.of("rankinglog", "textures/tutorial_1.png"), "5. 특별 이벤트 참여하기", "메인 화면의 이벤트 버튼을 통해 진행 중인 한정 이벤트에 참여하세요!\n참여 버튼을 누르고 특정 트랙을 달리면 이벤트 랭킹에 등록됩니다.")
    );

    private ButtonWidget prevBtn;
    private ButtonWidget nextBtn;

    public TutorialScreen(Screen parent) {
        super(Text.literal("모드 튜토리얼"));
        this.parent = parent; // 튜토리얼이 끝나면 돌아갈 화면
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // 이미지 박스를 큼직하게 설정
        int boxH = Math.min(220, this.height / 2 + 20);
        int boxY = Math.max(25, (this.height - boxH) / 2 - 35);
        int textSpace = 70; // 텍스트가 들어갈 여백
        int buttonY = boxY + boxH + textSpace;

        prevBtn = addDrawableChild(ButtonWidget.builder(Text.literal("◀ 이전"), b -> {
            if (page > 0) { page--; updateButtons(); }
        }).dimensions(cx - 110, buttonY, 100, 20).build());

        nextBtn = addDrawableChild(ButtonWidget.builder(Text.literal("다음 ▶"), b -> {
            if (page < pages.size() - 1) {
                page++;
                updateButtons();
            } else {
                // ★ 마지막 페이지에서 '시작하기'를 눌렀을 때

                // 1. 실제로 튜토리얼을 다 봤다고 설정에 저장 (나중에 테스트 끝나면 주석 해제하세요!)
                // ModConfig.get().hasSeenTutorial = true;
                // ModConfig.save();

                // 2. 부모 화면으로 돌아가거나, 없다면 그냥 닫기 (월드로 돌아가기)
                if (parent == null) {
                    this.close(); // 화면 닫고 게임으로 돌아감
                } else {
                    Objects.requireNonNull(this.client).setScreen(parent); // 메인 화면으로 돌아감
                }
            }
        }).dimensions(cx + 10, buttonY, 100, 20).build());

        updateButtons();
    }

    private void updateButtons() {
        prevBtn.active = (page > 0);
        if (page == pages.size() - 1) {
            nextBtn.setMessage(Text.literal("시작하기 ✔"));
        } else {
            nextBtn.setMessage(Text.literal("다음 ▶"));
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, ModConfig.get().getBgColor());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        int cx = this.width / 2;

        // 메인 메뉴보다 훨씬 넓고 높은 박스
        int boxW = Math.min(420, this.width - 40);
        int boxH = Math.min(220, this.height / 2 + 20);
        int boxX = cx - boxW / 2;
        int boxY = Math.max(25, (this.height - boxH) / 2 - 35);

        // 1. 상단 타이틀 (메인 화면 스타일 폰트 크기 확대)
        context.getMatrices().push();
        float titleScale = this.width < 400 ? 1.2f : 1.5f;
        context.getMatrices().scale(titleScale, titleScale, 1.0f);
        context.drawCenteredTextWithShadow(textRenderer, "§6[ 튜토리얼 ]", (int)(cx / titleScale), (int)((boxY - 18) / titleScale), 0xFFFFFF);
        context.getMatrices().pop();

        // 2. 이미지 박스 테두리 및 배경 (메인 화면의 공지사항 박스 스타일)
        context.fill(boxX - 1, boxY - 1, boxX + boxW + 1, boxY + boxH + 1, 0xFF555555);
        context.fill(boxX, boxY, boxX + boxW, boxY + boxH, 0xFF000000);

        TutorialPage current = pages.get(page);


// 3. 이미지 렌더링 (1.21.2+ 최신 API 규격 10 파라미터)
        context.drawTexture(
                net.minecraft.client.render.RenderLayer::getGuiTextured, // 1. 렌더 레이어 (GUI 기본 텍스처 모드)
                current.image(), // 2. Identifier (이미지 소스)
                boxX, boxY,      // 3, 4. x, y (화면 시작 좌표)
                0.0F, 0.0F,      // 5, 6. u, v (텍스처 자르기 시작점, float)
                boxW, boxH,      // 7, 8. width, height (화면에 그릴 실제 너비와 높이, int)
                boxW, boxH       // 9, 10. textureWidth, textureHeight (이미지 원본 해상도 스케일, int)
        );

        // 4. 하단 텍스트 영역
        int textY = boxY + boxH + 15;
        context.drawCenteredTextWithShadow(textRenderer, "§e§l" + current.title(), cx, textY, 0xFFFFFF);

        int descY = textY + 16;
        List<OrderedText> wrapped = textRenderer.wrapLines(Text.literal(current.desc()), boxW + 20);
        for (OrderedText line : wrapped) {
            context.drawCenteredTextWithShadow(textRenderer, line, cx, descY, 0xDDDDDD);
            descY += 12;
        }

        // 5. 페이지 번호 (1 / 5)
        context.drawCenteredTextWithShadow(textRenderer, (page + 1) + " / " + pages.size(), cx, nextBtn.getY() - 15, 0xAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}